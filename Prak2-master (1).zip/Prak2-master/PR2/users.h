#ifndef USERS_H
#define USERS_H

// Вывод списка пользователей и их домашних директорий
void list_users();

#endif // USERS_H

