#ifndef PROCESSES_H
#define PROCESSES_H

// Вывод списка процессов
void list_processes();

#endif // PROCESSES_H

