#ifndef HELP_H
#define HELP_H

// Вывод справки
void print_help();

#endif // HELP_H

